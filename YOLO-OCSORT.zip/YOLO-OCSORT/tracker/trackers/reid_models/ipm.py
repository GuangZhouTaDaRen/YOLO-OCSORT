import numpy as np

# 需要先定义这些常量，数值根据你的摄像头参数设置
FOV_H = 90.0  # 水平视场角，单位度（示例）
FOV_V = 60.0  # 垂直视场角，单位度（示例）
DEG2RAD = np.pi / 180.0

CAMERA_POS_X = 0   # 根据实际参数调整
CAMERA_POS_Y = 0
CAMERA_POS_Z = 1.5  # 摄像头高度，单位米，示例

def build_ipm_table(srcw, srch, dstw, dsth, vptx, vpty):
    alpha_h = 0.5 * FOV_H * DEG2RAD
    alpha_v = 0.5 * FOV_V * DEG2RAD
    gamma = -(vptx - (srcw >> 1)) * alpha_h / (srcw >> 1)  # 相机偏航角
    theta = -(vpty - (srch >> 1)) * alpha_v / (srch >> 1)  # 相机俯仰角

    front_map_start_position = dsth >> 1
    front_map_end_position = front_map_start_position + dsth
    side_map_mid_position = dstw >> 1
    front_map_scale_factor = 4
    side_map_scale_factor = 2

    maptable = np.full((dstw * dsth,), -1, dtype=np.int32)

    for y in range(dstw):
        for x in range(front_map_start_position, front_map_end_position):
            idx = y * dsth + (x - front_map_start_position)

            deltax = front_map_scale_factor * (front_map_end_position - x - CAMERA_POS_X)
            deltay = side_map_scale_factor * (y - side_map_mid_position - CAMERA_POS_Y)

            if deltay == 0:
                # 直接用上一行映射值避免除0
                if idx - dsth >= 0:
                    maptable[idx] = maptable[idx - dsth]
                else:
                    maptable[idx] = -1
            else:
                angle1 = np.arctan(deltay / deltax)
                angle2 = np.arctan(CAMERA_POS_Z * np.sin(angle1) / deltay)
                u = int((angle2 - (theta - alpha_v)) / (2 * alpha_v / srch))
                v = int((angle1 - (gamma - alpha_h)) / (2 * alpha_h / srcw))

                if 0 <= u < srch and 0 <= v < srcw:
                    maptable[idx] = srcw * u + v
                else:
                    maptable[idx] = -1

    return maptable.reshape((dstw, dsth))
