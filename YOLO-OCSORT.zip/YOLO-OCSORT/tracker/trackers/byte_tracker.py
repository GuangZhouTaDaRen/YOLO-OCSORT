# """
# ByteTrack
# """
#
# import numpy as np
# from collections import deque
# from .basetrack import BaseTrack, TrackState
# from .tracklet import Tracklet
# from .matching import *
#
#
# class ByteTracker(object):
#     def __init__(self, args, frame_rate=30):
#         self.tracked_tracklets = []  # type: list[Tracklet]
#         self.lost_tracklets = []  # type: list[Tracklet]
#         self.removed_tracklets = []  # type: list[Tracklet]
#
#         self.frame_id = 0
#         self.args = args
#
#         self.det_thresh = args.conf_thresh + 0.1
#         self.buffer_size = int(frame_rate / 30.0 * args.track_buffer)
#         self.max_time_lost = self.buffer_size
#
#         self.motion = args.kalman_format
#
#     def update(self, output_results, img, ori_img):
#         """
#         output_results: processed detections (scale to original size) tlbr format
#         """
#
#         self.frame_id += 1
#         activated_tracklets = []
#         refind_tracklets = []
#         lost_tracklets = []
#         removed_tracklets = []
#
#         scores = output_results[:, 4]
#         bboxes = output_results[:, :4]
#         categories = output_results[:, -1]
#
#         remain_inds = scores > self.args.conf_thresh
#         inds_low = scores > 0.1
#         inds_high = scores < self.args.conf_thresh
#
#         inds_second = np.logical_and(inds_low, inds_high)
#         dets_second = bboxes[inds_second]
#         dets = bboxes[remain_inds]
#
#         cates = categories[remain_inds]
#         cates_second = categories[inds_second]
#
#         scores_keep = scores[remain_inds]
#         scores_second = scores[inds_second]
#
#         if len(dets) > 0:
#             '''Detections'''
#             detections = [Tracklet(tlwh, s, cate, motion=self.motion) for
#                           (tlwh, s, cate) in zip(dets, scores_keep, cates)]
#         else:
#             detections = []
#
#         ''' Add newly detected tracklets to tracked_tracklets'''
#         unconfirmed = []
#         tracked_tracklets = []  # type: list[Tracklet]
#         for track in self.tracked_tracklets:
#             if not track.is_activated:
#                 unconfirmed.append(track)
#             else:
#                 tracked_tracklets.append(track)
#
#         ''' Step 2: First association, with high score detection boxes'''
#         tracklet_pool = joint_tracklets(tracked_tracklets, self.lost_tracklets)
#
#         # Predict the current location with Kalman
#         for tracklet in tracklet_pool:
#             tracklet.predict()
#
#         dists = iou_distance(tracklet_pool, detections)
#
#         matches, u_track, u_detection = linear_assignment(dists, thresh=0.9)
#
#         for itracked, idet in matches:
#             track = tracklet_pool[itracked]
#             det = detections[idet]
#             if track.state == TrackState.Tracked:
#                 track.update(detections[idet], self.frame_id)
#                 activated_tracklets.append(track)
#             else:
#                 track.re_activate(det, self.frame_id, new_id=False)
#                 refind_tracklets.append(track)
#
#         ''' Step 3: Second association, with low score detection boxes'''
#         # association the untrack to the low score detections
#         if len(dets_second) > 0:
#             '''Detections'''
#             detections_second = [Tracklet(tlwh, s, cate, motion=self.motion) for
#                                  (tlwh, s, cate) in zip(dets_second, scores_second, cates_second)]
#         else:
#             detections_second = []
#         r_tracked_tracklets = [tracklet_pool[i] for i in u_track if tracklet_pool[i].state == TrackState.Tracked]
#         dists = iou_distance(r_tracked_tracklets, detections_second)
#         matches, u_track, u_detection_second = linear_assignment(dists, thresh=0.5)
#         for itracked, idet in matches:
#             track = r_tracked_tracklets[itracked]
#             det = detections_second[idet]
#             if track.state == TrackState.Tracked:
#                 track.update(det, self.frame_id)
#                 activated_tracklets.append(track)
#             else:
#                 track.re_activate(det, self.frame_id, new_id=False)
#                 refind_tracklets.append(track)
#
#         for it in u_track:
#             track = r_tracked_tracklets[it]
#             if not track.state == TrackState.Lost:
#                 track.mark_lost()
#                 lost_tracklets.append(track)
#
#         '''Deal with unconfirmed tracks, usually tracks with only one beginning frame'''
#         detections = [detections[i] for i in u_detection]
#         dists = iou_distance(unconfirmed, detections)
#
#         matches, u_unconfirmed, u_detection = linear_assignment(dists, thresh=0.7)
#
#         for itracked, idet in matches:
#             unconfirmed[itracked].update(detections[idet], self.frame_id)
#             activated_tracklets.append(unconfirmed[itracked])
#         for it in u_unconfirmed:
#             track = unconfirmed[it]
#             track.mark_removed()
#             removed_tracklets.append(track)
#
#         """ Step 4: Init new tracklets"""
#         for inew in u_detection:
#             track = detections[inew]
#             if track.score < self.det_thresh:
#                 continue
#             track.activate(self.frame_id)
#             activated_tracklets.append(track)
#
#         """ Step 5: Update state"""
#         for track in self.lost_tracklets:
#             if self.frame_id - track.end_frame > self.max_time_lost:
#                 track.mark_removed()
#                 removed_tracklets.append(track)
#
#         # print('Ramained match {} s'.format(t4-t3))
#
#         self.tracked_tracklets = [t for t in self.tracked_tracklets if t.state == TrackState.Tracked]
#         self.tracked_tracklets = joint_tracklets(self.tracked_tracklets, activated_tracklets)
#         self.tracked_tracklets = joint_tracklets(self.tracked_tracklets, refind_tracklets)
#         self.lost_tracklets = sub_tracklets(self.lost_tracklets, self.tracked_tracklets)
#         self.lost_tracklets.extend(lost_tracklets)
#         self.lost_tracklets = sub_tracklets(self.lost_tracklets, self.removed_tracklets)
#         self.removed_tracklets.extend(removed_tracklets)
#         self.tracked_tracklets, self.lost_tracklets = remove_duplicate_tracklets(self.tracked_tracklets,
#                                                                                  self.lost_tracklets)
#         # get scores of lost tracks
#         output_tracklets = [track for track in self.tracked_tracklets if track.is_activated]
#
#         return output_tracklets
#
#
# def joint_tracklets(tlista, tlistb):
#     exists = {}
#     res = []
#     for t in tlista:
#         exists[t.track_id] = 1
#         res.append(t)
#     for t in tlistb:
#         tid = t.track_id
#         if not exists.get(tid, 0):
#             exists[tid] = 1
#             res.append(t)
#     return res
#
#
# def sub_tracklets(tlista, tlistb):
#     tracklets = {}
#     for t in tlista:
#         tracklets[t.track_id] = t
#     for t in tlistb:
#         tid = t.track_id
#         if tracklets.get(tid, 0):
#             del tracklets[tid]
#     return list(tracklets.values())
#
#
# def remove_duplicate_tracklets(trackletsa, trackletsb):
#     pdist = iou_distance(trackletsa, trackletsb)
#     pairs = np.where(pdist < 0.15)
#     dupa, dupb = list(), list()
#     for p, q in zip(*pairs):
#         timep = trackletsa[p].frame_id - trackletsa[p].start_frame
#         timeq = trackletsb[q].frame_id - trackletsb[q].start_frame
#         if timep > timeq:
#             dupb.append(q)
#         else:
#             dupa.append(p)
#     resa = [t for i, t in enumerate(trackletsa) if not i in dupa]
#     resb = [t for i, t in enumerate(trackletsb) if not i in dupb]
#     return resa, resb
#


"""
ByteTrack_DIOU
"""

import numpy as np
from collections import deque
from .basetrack import BaseTrack, TrackState
from .tracklet import Tracklet
from .matching import *


def tlwh_to_tlbr(tlwh):
    """
    Convert bounding boxes from (top-left x, y, width, height) to (left, top, right, bottom).
    注意：输入格式是 tlwh = [x, y, w, h]
    """
    x, y, w, h = tlwh
    return np.array([x, y, x + w, y + h])


def diou_distance(tracks, detections):
    """
    计算基于DIoU的距离矩阵
    tracks: list of Tracklet or list of tlwh boxes
    detections: list of Tracklet or list of tlwh boxes
    返回距离矩阵 dist，越小越近
    """
    if len(tracks) == 0 or len(detections) == 0:
        return np.empty((len(tracks), len(detections)))

    tracks_tlbr = np.array([tlwh_to_tlbr(t.tlwh if hasattr(t, 'tlwh') else t) for t in tracks])
    dets_tlbr = np.array([tlwh_to_tlbr(d.tlwh if hasattr(d, 'tlwh') else d) for d in detections])

    dist = np.zeros((len(tracks), len(detections)), dtype=np.float32)

    for i, track_box in enumerate(tracks_tlbr):
        x1_t, y1_t, x2_t, y2_t = track_box
        c_x_t = (x1_t + x2_t) / 2
        c_y_t = (y1_t + y2_t) / 2
        w_t = x2_t - x1_t
        h_t = y2_t - y1_t

        for j, det_box in enumerate(dets_tlbr):
            x1_d, y1_d, x2_d, y2_d = det_box
            c_x_d = (x1_d + x2_d) / 2
            c_y_d = (y1_d + y2_d) / 2
            w_d = x2_d - x1_d
            h_d = y2_d - y1_d

            # 计算交集
            xx1 = max(x1_t, x1_d)
            yy1 = max(y1_t, y1_d)
            xx2 = min(x2_t, x2_d)
            yy2 = min(y2_t, y2_d)

            inter_w = max(0, xx2 - xx1)
            inter_h = max(0, yy2 - yy1)
            inter_area = inter_w * inter_h

            area_t = w_t * h_t
            area_d = w_d * h_d
            union_area = area_t + area_d - inter_area

            iou = inter_area / union_area if union_area > 0 else 0

            # 中心点距离平方
            center_dist = (c_x_t - c_x_d) ** 2 + (c_y_t - c_y_d) ** 2

            # 包围框对角线平方
            enclosing_x1 = min(x1_t, x1_d)
            enclosing_y1 = min(y1_t, y1_d)
            enclosing_x2 = max(x2_t, x2_d)
            enclosing_y2 = max(y2_t, y2_d)
            c_diag = (enclosing_x2 - enclosing_x1) ** 2 + (enclosing_y2 - enclosing_y1) ** 2

            diou = iou - (center_dist / c_diag) if c_diag > 0 else iou

            dist[i, j] = 1 - diou

    return dist


class ByteTracker(object):
    def __init__(self, args, frame_rate=30):
        self.tracked_tracklets = []  # type: list[Tracklet]
        self.lost_tracklets = []  # type: list[Tracklet]
        self.removed_tracklets = []  # type: list[Tracklet]

        self.frame_id = 0
        self.args = args

        self.det_thresh = args.conf_thresh + 0.1
        self.buffer_size = int(frame_rate / 30.0 * args.track_buffer)
        self.max_time_lost = self.buffer_size

        self.motion = args.kalman_format

    def update(self, output_results, img, ori_img):
        """
        output_results: processed detections (scale to original size) tlbr format
        """

        self.frame_id += 1
        activated_tracklets = []
        refind_tracklets = []
        lost_tracklets = []
        removed_tracklets = []

        scores = output_results[:, 4]
        bboxes = output_results[:, :4]
        categories = output_results[:, -1]

        remain_inds = scores > self.args.conf_thresh
        inds_low = scores > 0.1
        inds_high = scores < self.args.conf_thresh

        inds_second = np.logical_and(inds_low, inds_high)
        dets_second = bboxes[inds_second]
        dets = bboxes[remain_inds]

        cates = categories[remain_inds]
        cates_second = categories[inds_second]

        scores_keep = scores[remain_inds]
        scores_second = scores[inds_second]

        if len(dets) > 0:
            '''Detections'''
            detections = [Tracklet(tlwh, s, cate, motion=self.motion) for
                          (tlwh, s, cate) in zip(dets, scores_keep, cates)]
        else:
            detections = []

        ''' Add newly detected tracklets to tracked_tracklets'''
        unconfirmed = []
        tracked_tracklets = []  # type: list[Tracklet]
        for track in self.tracked_tracklets:
            if not track.is_activated:
                unconfirmed.append(track)
            else:
                tracked_tracklets.append(track)

        ''' Step 2: First association, with high score detection boxes'''
        tracklet_pool = joint_tracklets(tracked_tracklets, self.lost_tracklets)

        # Predict the current location with Kalman
        for tracklet in tracklet_pool:
            tracklet.predict()

        dists = ciou_distance(tracklet_pool, detections)

        matches, u_track, u_detection = linear_assignment(dists, thresh=0.9)

        for itracked, idet in matches:
            track = tracklet_pool[itracked]
            det = detections[idet]
            if track.state == TrackState.Tracked:
                track.update(detections[idet], self.frame_id)
                activated_tracklets.append(track)
            else:
                track.re_activate(det, self.frame_id, new_id=False)
                refind_tracklets.append(track)

        ''' Step 3: Second association, with low score detection boxes'''
        # association the untrack to the low score detections
        if len(dets_second) > 0:
            '''Detections'''
            detections_second = [Tracklet(tlwh, s, cate, motion=self.motion) for
                                 (tlwh, s, cate) in zip(dets_second, scores_second, cates_second)]
        else:
            detections_second = []
        r_tracked_tracklets = [tracklet_pool[i] for i in u_track if tracklet_pool[i].state == TrackState.Tracked]
        dists = ciou_distance(r_tracked_tracklets, detections_second)
        matches, u_track, u_detection_second = linear_assignment(dists, thresh=0.5)
        for itracked, idet in matches:
            track = r_tracked_tracklets[itracked]
            det = detections_second[idet]
            if track.state == TrackState.Tracked:
                track.update(det, self.frame_id)
                activated_tracklets.append(track)
            else:
                track.re_activate(det, self.frame_id, new_id=False)
                refind_tracklets.append(track)

        for it in u_track:
            track = r_tracked_tracklets[it]
            if not track.state == TrackState.Lost:
                track.mark_lost()
                lost_tracklets.append(track)

        '''Deal with unconfirmed tracks, usually tracks with only one beginning frame'''
        detections = [detections[i] for i in u_detection]
        dists = ciou_distance(unconfirmed, detections)

        matches, u_unconfirmed, u_detection = linear_assignment(dists, thresh=0.7)

        for itracked, idet in matches:
            unconfirmed[itracked].update(detections[idet], self.frame_id)
            activated_tracklets.append(unconfirmed[itracked])
        for it in u_unconfirmed:
            track = unconfirmed[it]
            track.mark_removed()
            removed_tracklets.append(track)

        """ Step 4: Init new tracklets"""
        for inew in u_detection:
            track = detections[inew]
            if track.score < self.det_thresh:
                continue
            track.activate(self.frame_id)
            activated_tracklets.append(track)

        """ Step 5: Update state"""
        for track in self.lost_tracklets:
            if self.frame_id - track.end_frame > self.max_time_lost:
                track.mark_removed()
                removed_tracklets.append(track)

        self.tracked_tracklets = [t for t in self.tracked_tracklets if t.state == TrackState.Tracked]
        self.tracked_tracklets = joint_tracklets(self.tracked_tracklets, activated_tracklets)
        self.tracked_tracklets = joint_tracklets(self.tracked_tracklets, refind_tracklets)
        self.lost_tracklets = sub_tracklets(self.lost_tracklets, self.tracked_tracklets)
        self.lost_tracklets.extend(lost_tracklets)
        self.lost_tracklets = sub_tracklets(self.lost_tracklets, self.removed_tracklets)
        self.removed_tracklets.extend(removed_tracklets)
        self.tracked_tracklets, self.lost_tracklets = remove_duplicate_tracklets(self.tracked_tracklets,
                                                                                 self.lost_tracklets)
        # get scores of lost tracks
        output_tracklets = [track for track in self.tracked_tracklets if track.is_activated]

        return output_tracklets


def joint_tracklets(tlista, tlistb):
    exists = {}
    res = []
    for t in tlista:
        exists[t.track_id] = 1
        res.append(t)
    for t in tlistb:
        tid = t.track_id
        if not exists.get(tid, 0):
            exists[tid] = 1
            res.append(t)
    return res


def sub_tracklets(tlista, tlistb):
    tracklets = {}
    for t in tlista:
        tracklets[t.track_id] = t
    for t in tlistb:
        tid = t.track_id
        if tracklets.get(tid, 0):
            del tracklets[tid]
    return list(tracklets.values())


def remove_duplicate_tracklets(trackletsa, trackletsb):
    pdist = ciou_distance(trackletsa, trackletsb)
    pairs = np.where(pdist < 0.15)
    dupa, dupb = list(), list()
    for p, q in zip(*pairs):
        timep = trackletsa[p].frame_id - trackletsa[p].start_frame
        timeq = trackletsb[q].frame_id - trackletsb[q].start_frame
        if timep > timeq:
            dupb.append(q)
        else:
            dupa.append(p)
    resa = [t for i, t in enumerate(trackletsa) if not i in dupa]
    resb = [t for i, t in enumerate(trackletsb) if not i in dupb]
    return resa, resb


def giou_distance(tracks, detections):
    if len(tracks) == 0 or len(detections) == 0:
        return np.empty((len(tracks), len(detections)))

    tracks_tlbr = np.array([tlwh_to_tlbr(t.tlwh if hasattr(t, 'tlwh') else t) for t in tracks])
    dets_tlbr = np.array([tlwh_to_tlbr(d.tlwh if hasattr(d, 'tlwh') else d) for d in detections])
    dist = np.zeros((len(tracks), len(detections)), dtype=np.float32)

    for i, box1 in enumerate(tracks_tlbr):
        x1_1, y1_1, x2_1, y2_1 = box1
        area1 = (x2_1 - x1_1) * (y2_1 - y1_1)
        for j, box2 in enumerate(dets_tlbr):
            x1_2, y1_2, x2_2, y2_2 = box2
            area2 = (x2_2 - x1_2) * (y2_2 - y1_2)

            inter_x1 = max(x1_1, x1_2)
            inter_y1 = max(y1_1, y1_2)
            inter_x2 = min(x2_1, x2_2)
            inter_y2 = min(y2_1, y2_2)
            inter_w = max(0, inter_x2 - inter_x1)
            inter_h = max(0, inter_y2 - inter_y1)
            inter_area = inter_w * inter_h

            union_area = area1 + area2 - inter_area
            iou = inter_area / union_area if union_area > 0 else 0

            enclose_x1 = min(x1_1, x1_2)
            enclose_y1 = min(y1_1, y1_2)
            enclose_x2 = max(x2_1, x2_2)
            enclose_y2 = max(y2_1, y2_2)
            enclose_area = (enclose_x2 - enclose_x1) * (enclose_y2 - enclose_y1)

            giou = iou - (enclose_area - union_area) / enclose_area if enclose_area > 0 else iou
            dist[i, j] = 1 - giou
    return dist




def ciou_distance(tracks, detections):
    if len(tracks) == 0 or len(detections) == 0:
        return np.empty((len(tracks), len(detections)))

    tracks_tlbr = np.array([tlwh_to_tlbr(t.tlwh if hasattr(t, 'tlwh') else t) for t in tracks])
    dets_tlbr = np.array([tlwh_to_tlbr(d.tlwh if hasattr(d, 'tlwh') else d) for d in detections])
    dist = np.zeros((len(tracks), len(detections)), dtype=np.float32)

    for i, box1 in enumerate(tracks_tlbr):
        x1_1, y1_1, x2_1, y2_1 = box1
        w1, h1 = x2_1 - x1_1, y2_1 - y1_1
        area1 = w1 * h1
        cx1, cy1 = (x1_1 + x2_1) / 2, (y1_1 + y2_1) / 2

        for j, box2 in enumerate(dets_tlbr):
            x1_2, y1_2, x2_2, y2_2 = box2
            w2, h2 = x2_2 - x1_2, y2_2 - y1_2
            area2 = w2 * h2
            cx2, cy2 = (x1_2 + x2_2) / 2, (y1_2 + y2_2) / 2

            inter_x1 = max(x1_1, x1_2)
            inter_y1 = max(y1_1, y1_2)
            inter_x2 = min(x2_1, x2_2)
            inter_y2 = min(y2_1, y2_2)
            inter_w = max(0, inter_x2 - inter_x1)
            inter_h = max(0, inter_y2 - inter_y1)
            inter_area = inter_w * inter_h

            union_area = area1 + area2 - inter_area
            iou = inter_area / union_area if union_area > 0 else 0

            center_dist = (cx1 - cx2) ** 2 + (cy1 - cy2) ** 2
            enclose_w = max(x2_1, x2_2) - min(x1_1, x1_2)
            enclose_h = max(y2_1, y2_2) - min(y1_1, y1_2)
            c_diag = enclose_w ** 2 + enclose_h ** 2

            v = (4 / (np.pi ** 2)) * (np.arctan(w2 / h2) - np.arctan(w1 / h1)) ** 2
            alpha = v / (1 - iou + v) if iou < 1 else 0
            ciou = iou - (center_dist / c_diag + alpha * v) if c_diag > 0 else iou
            dist[i, j] = 1 - ciou
    return dist



def eiou_distance(tracks, detections):
    if len(tracks) == 0 or len(detections) == 0:
        return np.empty((len(tracks), len(detections)))

    tracks_tlbr = np.array([tlwh_to_tlbr(t.tlwh if hasattr(t, 'tlwh') else t) for t in tracks])
    dets_tlbr = np.array([tlwh_to_tlbr(d.tlwh if hasattr(d, 'tlwh') else d) for d in detections])
    dist = np.zeros((len(tracks), len(detections)), dtype=np.float32)

    for i, box1 in enumerate(tracks_tlbr):
        x1_1, y1_1, x2_1, y2_1 = box1
        w1, h1 = x2_1 - x1_1, y2_1 - y1_1
        cx1, cy1 = (x1_1 + x2_1) / 2, (y1_1 + y2_1) / 2

        for j, box2 in enumerate(dets_tlbr):
            x1_2, y1_2, x2_2, y2_2 = box2
            w2, h2 = x2_2 - x1_2, y2_2 - y1_2
            cx2, cy2 = (x1_2 + x2_2) / 2, (y1_2 + y2_2) / 2

            inter_x1 = max(x1_1, x1_2)
            inter_y1 = max(y1_1, y1_2)
            inter_x2 = min(x2_1, x2_2)
            inter_y2 = min(y2_1, y2_2)
            inter_w = max(0, inter_x2 - inter_x1)
            inter_h = max(0, inter_y2 - inter_y1)
            inter_area = inter_w * inter_h

            area1 = w1 * h1
            area2 = w2 * h2
            union_area = area1 + area2 - inter_area
            iou = inter_area / union_area if union_area > 0 else 0

            center_dist = (cx1 - cx2) ** 2 + (cy1 - cy2) ** 2
            cw = max(x2_1, x2_2) - min(x1_1, x1_2)
            ch = max(y2_1, y2_2) - min(y1_1, y1_2)
            c_diag = cw ** 2 + ch ** 2

            w_dist = (w1 - w2) ** 2
            h_dist = (h1 - h2) ** 2

            eiou = iou - (center_dist / c_diag + w_dist / (cw ** 2 + 1e-7) + h_dist / (ch ** 2 + 1e-7)) if c_diag > 0 else iou
            dist[i, j] = 1 - eiou
    return dist
