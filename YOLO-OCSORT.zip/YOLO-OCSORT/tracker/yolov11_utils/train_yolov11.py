import torch 
from ultralytics import YOLO
import numpy as np  

import argparse

def main(args):
    """ main func
    
    """

    model = YOLO(model=args.model_weight)
    model.train(
        data=args.data_cfg,
        epochs=args.epochs,
        batch=args.batch_size,
        imgsz=args.img_sz,
        patience=50,  # epochs to wait for no observable improvement for early stopping of training
        device=args.device,
    )


if __name__ == '__main__':
    parser = argparse.ArgumentParser("YOLO v8 train parser")

    parser.add_argument('--model', type=str, default='/data/CuiTengPeng/yolov7_tracker/ultralytics/cfg/models/11/yolo11_Down_wt_MSAA_smallhead.yaml', help='yaml or pt file')
    parser.add_argument('--model_weight', type=str, default='/data/CuiTengPeng/yolov7_tracker/tracker/yolov11_utils/best.pt', help='')
    parser.add_argument('--data_cfg', type=str, default='/data/CuiTengPeng/yolov7_tracker/data/my_pet_2.yaml', help='')
    parser.add_argument('--epochs', type=int, default=30, help='')
    parser.add_argument('--batch_size', type=int, default=32, help='')
    parser.add_argument('--img_sz', type=int, default=640, help='')
    parser.add_argument('--device', type=str, default='1', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')

    args = parser.parse_args()

    main(args)